# 首个端到端验收脚本

1. `python -m unittest discover -s tests -v` 全部成功。
2. `python -m app.server`，打开 `http://127.0.0.1:8765`。
3. 选「视觉识别」并开启摄像头或选择 JPG，执行识别；Demo 模式应显示【模拟演示】而不假称识别结果。
4. 选「AR 翻译」，翻译反馈显示在 HUD 叠加层，且标注真实/模拟来源。
5. 输入「查看某台设备温度」生成任务卡，在点击确认前状态必须 `awaiting_confirmation`；点击后应为 `confirmed_local_only`，不可假定已操作设备。
6. 保存一条笔记，读取状态，再执行删除；笔记、任务数组应为空。
7. 把 `AI_PROVIDER=openai` 并提供合法密钥，手动识别一张有外文标签的照片；确认 AI 服务返回译文。**此项需要网络/密钥，在本地默认不执行**。
8. 运行 Halo emulator 并截屏 `halo/main.lua`；检查按钮事件是否发出 `CAPTURE`。**此项需要安装上游 emulator，本包暂未验证**。
9. 真实 AR 眼镜硬件上显示字幕属于下一 Gate B；禁止将浏览器预览当作该门槛通过。
