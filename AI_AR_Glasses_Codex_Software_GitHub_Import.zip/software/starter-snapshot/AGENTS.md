# Codex 开发指令 — AI/AR Glasses V1

## 项目目标（不许重新收缩功能）
开发「L1 信息显示 + L2 视觉 AI 增强现实」眼镜 V1，保持 `docs/FEATURES_F01_F22.md` 的 16 P0、5 P1、1 预研，F15/F17/F19/F20/F22 属于首代 P0。禁用“先做无显示 AI 眼镜作为最终版本”的建议。可以阶段性用无屏开发板验证，但最终首版包含 AR 显示。

## 当前现状
已有运行的浏览器 AR HUD/手机中枢模拟器和 localhost API；已有 Halo Lua 端侧示例；尚无真实手机 App、眼镜硬件、PCB 生产文件。不要将 mock 当真实识别，不要伪称实机测试通过。

## 执行优先级
1. 阅读 README.md、docs/FEATURES_F01_F22.md、docs/ARCHITECTURE.md、docs/SPRINT_01.md。
2. 先运行 `python -m unittest discover -s tests -v`，确认行为可重现。
3. 完善视觉 AI 数据契约：image/jpeg/png、mode、HUD 结果/超时/错误；补测试。
4. 为真实手机 App 建立 Flutter 项目，对接已有 API，不得把密钥放 App；加 BLE 设备接口适配层。
5. 对接 Brilliant Halo SDK，先在官方 emulator 测试 Lua 端文字与事件；中文采用栅格化，不直接绘制多字节 UTF-8。
6. 用 ESP32-S3 官方开发板 + OV2640 摄像头 + I2S/PDM 音频验证采集、功耗和链路，固件从 `78/xiaozhi-esp32`/`Visionbridge-AI-Glasses` 选择可兼容分支，保留上游许可证和依赖。
7. 完成元件选型、原理图、电源安全、Pin Map、KiCad ERC/DRC 后方可设计/导出 Gerber。AR 显示在独立光学驱动子系统，不得声称 ESP32-S3 DVP = MIPI DSI。

## 强制工程红线
- 物理摄像指示灯必须和摄像头供电/实际采集联动，不能仅靠 App 文案模拟。
- 任何外部执行动作必须用户显式确认；当前已确认任务仍标识 `confirmed_local_only`。
- 不得提交云 API Key、个人图片、音频数据和日志；默认 localhost、最小留存、明确删除范围。
- 无法确认第三方 LICENSE，禁止复制工程文件或纳入商业产品；只能阅读参考。
- 必须提供测试输出和可复现运行步骤，不能把未测试代码写成“已完成”。
- 眼镜鼻梁、耳后、太阳穴配重、近视/散光镜片适配必须在机械审查中列为 P0。

## 下一条 Codex 工作指令（直接开始，不提问）
“按本仓库 AGENTS.md 与 docs/SPRINT_01.md 实现 Sprint-01 的软件闭环。保留现有 HTTP API，增加契约测试和图像传输超时/重试；建立 Flutter 手机 App 工程，用摄像头与 BLE 适配器接口、AR HUD 预览、显式采集同意和任务确认；将 Halo Lua demo 用官方 emulator 执行并记录测试截图。不要伪造硬件检测结果。每完成一个任务运行测试并附上命令及结果。”
