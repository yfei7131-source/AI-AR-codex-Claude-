-- Halo display / button communication proof of concept.
-- Works with firmware-supported frame.* calls, also suitable for Halo emulator.
-- NOTICE: ASCII only. Chinese overlay needs host-side bitmap/rasterized text.
local function draw(title, text)
  frame.display.clear(0x00121A)
  frame.display.rect(8, 36, 240, 170, 0x087B6D, false)
  frame.display.text(title, 18, 48, 0x6CF5DE)
  frame.display.line(18, 66, 232, 66, 0x2B9885)
  frame.display.text(string.sub(text, 1, 26), 18, 85, 0xFFFFFF)
  frame.display.text('Tap button: capture', 18, 180, 0xB0E6DD)
end

draw('AI/AR GLASSES V1', 'Waiting for phone...')
frame.bluetooth.receive_callback(function(data)
  draw('AR HUD UPDATE', tostring(data))
end)
frame.button.single(function()
  frame.bluetooth.send('CAPTURE')
  draw('CAPTURE REQUEST', 'Sent to companion')
end)
while true do
  frame.sleep(0.25)
end
