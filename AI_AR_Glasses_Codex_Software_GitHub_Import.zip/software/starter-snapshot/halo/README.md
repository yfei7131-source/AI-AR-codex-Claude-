# Brilliant Halo 端侧 Lua 原型

`main.lua` 使用官方 `frame.display`、`frame.bluetooth.receive_callback`、`frame.button.single` 接口：在 HUD 显示 ASCII 提示；按钮单击发出 `CAPTURE` 消息。**只是技术验证，不是已经完成真实手机蓝牙配对**。

官方 SDK： https://github.com/brilliantlabsAR/brilliant_sdk
官方显示/按键 API： https://raw.githubusercontent.com/brilliantlabsAR/docs/main/halo/halo-sdk-lua.md

如本机可安装 `halo-emulator`，从项目根目录执行 `halo-emulator ./halo/` 可进行端侧图像验证；具体安装方式依当前官方仓库 README（该项目文档对 PyPI/源码安装说明有版本差异）核实。这里不将运行成功当作已验证事实。

限制：Halo 端侧默认字体主要用于英文 ASCII；简体中文的 AR 翻译字幕应在手机端使用官方 `brilliant_msg` 的文字栅格化/bitmap 路径发送。单字节 demo 协议仅用于起步，正式通信需按官方 SDK 消息协议和 MTU 分包进行。
