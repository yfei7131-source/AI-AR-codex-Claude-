# ESP32-S3 设备固件开发工作区

当前没有放入虚假的可编译 ESP-IDF 工程。优先参考：
- https://github.com/78/xiaozhi-esp32 （语音基础、MIT；检查最新 ESP-IDF 版本）
- https://github.com/nickjizheng/Visionbridge-AI-Glasses （眼镜摄像/语音，具体硬件 Pin Map 需手动核实）

建议真实开发步骤：先使用带 PSRAM 的 ESP32-S3 摄像头开发板跑最小 DVP/JPEG demo；随后加入音频、按钮和物理摄像指示；根据开发板原理图生成经过核实的 `board_pins.h`。在器件/排线型号未确定前不编造 GPIO。设备端只发布捕获事件与数据，AI 推理和 AR HUD 由手机/显示适配层完成。
