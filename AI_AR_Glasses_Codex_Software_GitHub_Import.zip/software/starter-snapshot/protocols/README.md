# 应用消息定义（草案）

样例：

```json
{"version":"1.0","event":"capture.request","request_id":"req0001","timestamp_ms":0,"payload":{"reason":"user_button"}}
```

`request_id` 用于重试去重。设备控制面和媒体数据面分开；不要通过 BLE JSON 一次传完整 JPEG。需要对 BLE MTU、分片、超时、丢包、重发、加密、配对和授权分别实现/验证。Halo 原型 Lua `CAPTURE` 是仅用于 Hello World 的简化消息，不是此 JSON 协议已经上线。
