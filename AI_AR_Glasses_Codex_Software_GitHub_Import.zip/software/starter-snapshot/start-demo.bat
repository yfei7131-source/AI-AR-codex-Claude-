@echo off
setlocal
cd /d "%~dp0"
echo Starting AI/AR Glasses V1 prototype...
echo Open http://127.0.0.1:8765 in Chrome or Edge.
py -3 -m app.server || python -m app.server
pause
