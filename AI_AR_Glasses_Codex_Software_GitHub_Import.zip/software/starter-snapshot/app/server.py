"""Local-only prototype HTTP server. Usage: python -m app.server"""
from __future__ import annotations
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import RLock
from urllib.parse import urlsplit
from app.core import Memory, to_hud
from app.provider import build_provider, ProviderError

ROOT = Path(__file__).resolve().parents[1]
WEB_ROOT = ROOT / "web"
STATE = Memory()
LOCK = RLock()
PROVIDER = build_provider()
MAX_BODY = 3 * 1024 * 1024


class Handler(BaseHTTPRequestHandler):
    server_version = "AIARPrototype/0.1"

    def _json(self, status: int, payload: dict):
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/api/health":
            return self._json(200, {"ok": True, "provider": PROVIDER.name, "note": "本地原型，非真实AR眼镜固件"})
        if path == "/api/state":
            with LOCK:
                return self._json(200, STATE.snapshot())
        if path not in ("/", "/index.html"):
            return self._json(404, {"error": "not_found"})
        raw = (WEB_ROOT / "index.html").read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'unsafe-inline' 'self'; style-src 'unsafe-inline' 'self'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'")
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        path = urlsplit(self.path).path
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if not (0 < n <= MAX_BODY):
                return self._json(413, {"error": "请求体为空或超过3MB"})
            data = json.loads(self.rfile.read(n))
            if not isinstance(data, dict):
                raise ValueError("请求必须是JSON对象")
            if path == "/api/ask":
                kind = data.get("kind", "vision")
                if kind not in ("vision", "translate", "chat"):
                    raise ValueError("无效模式")
                question = str(data.get("question", "")).strip()[:500]
                if not question and kind != "translate":
                    raise ValueError("请输入问题")
                image_data = data.get("image_data")
                if image_data is not None and (not isinstance(image_data, str) or len(image_data) > 2_800_000):
                    raise ValueError("图片过大或格式错误")
                answer = PROVIDER.respond(question or "翻译画面中的文字", image_data, kind)
                hud = to_hud(kind, answer)
                with LOCK:
                    STATE.last_hud = hud
                return self._json(200, {"answer": answer, "hud": hud, "provider": PROVIDER.name})
            if path == "/api/notes":
                with LOCK:
                    note = STATE.note(str(data.get("text", ""))[:2000])
                    return self._json(201, {"note": note})
            if path == "/api/tasks/draft":
                with LOCK:
                    task = STATE.draft_task(str(data.get("text", ""))[:500])
                    return self._json(201, {"task": task, "hud": STATE.last_hud})
            if path == "/api/tasks/confirm":
                with LOCK:
                    task = STATE.confirm_task(str(data.get("id", "")))
                    return self._json(200, {"task": task, "hud": STATE.last_hud})
            if path == "/api/privacy/delete":
                with LOCK:
                    return self._json(200, STATE.wipe())
            return self._json(404, {"error": "not_found"})
        except (ValueError, json.JSONDecodeError) as exc:
            return self._json(400, {"error": str(exc)})
        except ProviderError as exc:
            return self._json(502, {"error": str(exc)})


def main():
    port = int(os.getenv("PORT", "8765"))
    addr = os.getenv("BIND_HOST", "127.0.0.1")
    print(f"AI/AR Glasses V1 demo: http://{addr}:{port} | provider={PROVIDER.name}")
    ThreadingHTTPServer((addr, port), Handler).serve_forever()


if __name__ == "__main__":
    main()
