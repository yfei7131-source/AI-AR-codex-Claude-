"""Mock and optional live multimodal inference via OpenAI Responses API.

Only the server may read OPENAI_API_KEY. Never put keys in browser, firmware, or Git.
"""
from __future__ import annotations
import json
import os
from urllib import request, error


class ProviderError(Exception):
    pass


class DemoProvider:
    """Explicit deterministic simulation: does not inspect actual pixels."""
    name = "demo"

    def respond(self, question: str, image_data: str | None = None, kind: str = "vision") -> str:
        if kind == "translate":
            return "【模拟演示，不是真实识别】请配置云端模型后对摄像头中的文字执行 OCR + 翻译。"
        if kind == "chat":
            return "【模拟演示】已收到问题：" + question[:120]
        return "【模拟演示，不是真实识别】收到图像输入：" + ("有" if image_data else "无") + "；问题：" + question[:100]


class OpenAIProvider:
    name = "openai"

    def __init__(self):
        self.key = os.environ.get("OPENAI_API_KEY", "")
        self.model = os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")
        if not self.key:
            raise ProviderError("未配置 OPENAI_API_KEY")

    def respond(self, question: str, image_data: str | None = None, kind: str = "vision") -> str:
        prompt = {
            "translate": "识别图像中可见的外语文字并翻译成简体中文。适合AR字幕，控制在80字以内，不能确定时说明。",
            "vision": "简明回答用户关于眼前画面的提问；不要编造看不见的细节。输出适合AR眼镜的简短中文反馈。",
            "chat": "用简洁中文回答用户。"
        }.get(kind, "简洁回答。") + "\n用户：" + question
        content = [{"type": "input_text", "text": prompt}]
        if image_data:
            if not image_data.startswith(("data:image/jpeg;base64,", "data:image/png;base64,")):
                raise ProviderError("只允许 JPEG 或 PNG data URL")
            content.append({"type": "input_image", "image_url": image_data, "detail": "low"})
        body = json.dumps({"model": self.model, "input": [{"role": "user", "content": content}], "store": False}, ensure_ascii=False).encode("utf-8")
        req = request.Request("https://api.openai.com/v1/responses", data=body, headers={
            "Authorization": "Bearer " + self.key, "Content-Type": "application/json"
        }, method="POST")
        try:
            with request.urlopen(req, timeout=40) as resp:
                result = json.load(resp)
        except error.HTTPError as exc:
            raise ProviderError(f"模型服务 HTTP {exc.code}；请检查模型、API余额和访问权限") from exc
        except (error.URLError, TimeoutError) as exc:
            raise ProviderError("模型服务连接失败") from exc
        texts = []
        for item in result.get("output", []):
            for part in item.get("content", []):
                if part.get("type") == "output_text":
                    texts.append(part.get("text", ""))
        if not texts:
            raise ProviderError("模型未返回可显示文本")
        return "\n".join(texts)


def build_provider():
    if os.getenv("AI_PROVIDER", "demo").lower() == "openai":
        return OpenAIProvider()
    return DemoProvider()
