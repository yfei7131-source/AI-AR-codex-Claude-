# AI/AR Glasses V1 — 首期可运行工程包

**产品定位：L1 信息显示 + L2 视觉 AI 增强现实。AR 显示是首版 P0，不得删除。**

日期：2026-11-10；当前交付：**手机中枢 / AR HUD 浏览器原型 + 可选真实视觉 AI 接口 + Halo Lua 最小示例 + 工程任务和 PCB 门槛**。

## 立即启动（Windows / macOS / Linux）

1. 安装 Python 3.10+，进入本目录。
2. 运行：

   ```bash
   python -m app.server
   ```

3. 浏览器打开 http://127.0.0.1:8765
4. 点击摄像头→拍摄→「识别并投射到 HUD」，或先上传 JPEG / PNG；试用「AR 翻译」「任务卡」「语音输入」「笔记」「隐私删除」。

默认 **DEMO 模式**：所有回答显式标注模拟，不具备真实 OCR、图像理解或翻译能力。摄像头采集、HUD 更新、任务确认和笔记存取接口是可运行代码；HUD 在浏览器模拟，不是眼镜真显示。

## 启用真实视觉 AI（可选，需自行配置接口密钥与账单）

请先确定当地网络和账户可访问 API。安装无需第三方 Python 包。密钥仅放在启动服务的终端环境变量，绝不能写到代码、浏览器或 ESP32 固件。

Windows PowerShell:

```powershell
$env:AI_PROVIDER="openai"
$env:OPENAI_API_KEY="你的API密钥"
$env:OPENAI_MODEL="gpt-4.1-mini"
python -m app.server
```

macOS/Linux:

```bash
export AI_PROVIDER=openai
export OPENAI_API_KEY='你的API密钥'
export OPENAI_MODEL=gpt-4.1-mini
python -m app.server
```

如果模型名在你的 API 账户不可用，请按官方模型列表调整。图像在你主动点击识别时经服务端转发给 AI 服务；本服务使用 `store:false` 参数请求不保存响应对象，但第三方数据处理和账户级保留规则不受本地删除功能控制。

## 运行自检

```bash
python -m unittest discover -s tests -v
```

## 交付范围

- `web/index.html` — 可操作 HUD / 摄像头 / AR 字幕模拟器，包含语音浏览器兼容性退化处理
- `app/server.py` — localhost API、状态与隐私删除
- `app/provider.py` — 明确演示与真实模型服务隔离
- `app/core.py` — 笔记、任务确认流程、HUD 格式化
- `halo/main.lua` — Halo 端侧显示及按键消息最小代码（未进行实机验证）
- `docs/` — 冻结功能 F01-F22、开发架构、开源复用清单、验收标准、开发迭代
- `hardware/` — 嘉立创 PCB 前必须完成的工程门槛
- `protocols/` — 眼镜 / 手机 / HUD 消息协议草案
- `AGENTS.md` — 可直接给 Codex 的开发约束和执行顺序

## 重要边界

这不是已完成的手机原生 App、ESP32 固件、真实 AR 光学显示或可下单 Gerber。现有开源 ESP32-S3 主板参考大多无 AR 显示，不能在没有显示桥接、光学元件和工艺验证时直接照搬。参见 `docs/OPEN_SOURCE.md` 与 `hardware/PCB_CHECKLIST.md`。

本项目源代码（本次新增文件）可由使用者修改；第三方项目代码并未打包到此 ZIP，使用时要独立检查许可证和硬件风险。
