# 软件目录

- `starter-snapshot/`：2026-11-10 最初工程（包含服务端、Web HUD、Lua 示例和初版测试）。
- `current/`：预留给 Codex 当前工作区的最新源码；本导入包 **不包含** 它。

不得将旧快照的 `tests/` 或 API 行为解释为 Sprint 02 的完整测试与实现。参见 `docs/software/sprint02/SPRINT02_REPORT.md`。
