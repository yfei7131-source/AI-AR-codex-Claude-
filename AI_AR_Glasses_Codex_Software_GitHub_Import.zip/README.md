# AI/AR Glasses V1.0 — Codex × Claude

本仓库用于软件（Codex）与硬件（Claude）的协同研发。

## 现有文件的真实性说明

- `software/starter-snapshot/` 是 **2026-11-10 初始工程快照**（22 个文件），用于恢复历史演示和接口参考；**不是最新 Sprint 02/S04 软件代码**。
- `docs/software/sprint01/` 为 Codex Sprint 01 归档报告与需求矩阵。
- `docs/software/sprint02/SPRINT02_REPORT.md` 为 Codex Sprint 02 交付报告，报告中的新 `mobile/`、ESP-IDF 工程等 **最新完整源码未包含在此前上传的附件里**。
- 此导入包不包含 Android APK、测试拍摄图片、密钥、编译缓存或带有用户隐私的数据。

## 当前阶段（以提交的证据为准）

- 软件：S04，iOS / Flutter / Web 适配，Codex 正在迭代；Sprint 02 报告为上一个有文档证据的交付。
- 硬件：H01.0，尚未正式启动 Claude 研发；**不锁定 ESP32-S3**，先核对 AR 光学接口与主控选型。

## 后续上传正式最新代码的顺序

1. 从 **Codex 实际工作的本地项目文件夹**取最新工程（含 `app/`、`mobile/`、`firmware/`、`protocols/`、`tests/`、`docs/`），而不是以本归档快照替代。
2. 审核 `.gitignore`，排除 `.env`、API Key、照片/音频、测试隐私数据、构建输出、APK 和固件二进制。
3. 将最新代码整理到仓库 **`software/current/`**，保留可重现构建的必要文本配置与锁文件。
4. 将 Claude 的硬件设计放在 `hardware/`，跨端协议放 `protocols/`，由负责人联合审查后修改。
5. 运行测试并附上实际命令、结果、Commit SHA；不要把模拟测试标为真机验收。

## Windows 上传（建议由 Codex 执行）

先在 GitHub 登录到有写入权限的账号，在本地克隆仓库，再复制本导入包文件到仓库根目录进行提交。请特别注意：如果仓库已有 README，先审阅本导入说明，避免覆盖已经更新的项目资料。

```powershell
git clone https://github.com/yfei7131-source/AI-AR-codex-Claude-.git
cd AI-AR-codex-Claude-
# 把本ZIP解压后的全部文件复制到这里，并确认 .gitignore 没有漏掉敏感文件
git add .
git diff --cached --stat
git commit -m "docs: import AI/AR starter snapshot and Codex reports"
git push origin main
```

如需最新软件源代码：由 Codex 在原 Windows 工作区直接完成同步，不能使用此 2026-11-10 初始快照替代。
