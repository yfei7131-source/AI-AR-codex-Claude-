# 软硬件共享接口

Codex 与 Claude 在本目录维护唯一可信的版本化 BLE GATT、Wi-Fi 图片传输、HUD 消息、错误码与安全协议。当前尚未从最新版 Codex 工作区导入协议源码，初始草案仅存放在 `software/starter-snapshot/protocols/`。
