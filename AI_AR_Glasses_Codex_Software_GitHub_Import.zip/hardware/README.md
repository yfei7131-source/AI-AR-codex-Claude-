# 硬件研发（Claude）

当前尚未有 Claude 产生的原理图、BOM、PCB 文件。H01 从架构、光学接口及主控候选比较开始，不预先锁定 ESP32-S3。

禁止将旧快照内 `software/starter-snapshot/hardware/` 视为最新硬件设计或可生产 PCB。
