> 历史归档，非当前最新源码；保留原始阶段内容以便追溯。

# AI/AR Glasses V1 — 首期可运行工程包

**产品定位：L1 信息显示 + L2 视觉 AI 增强现实。AR 显示是首版 P0，不得删除。**

日期：2026-11-10；当前交付：**手机中枢 / AR HUD 浏览器原型 + 严格区分 Demo/Live 的视觉 AI 接口 + Halo Lua 最小示例 + 需求追踪与硬件门槛**。真实云识别尚待配置 Key 验收，光学 AR 尚未实测。

## 立即启动（Windows / macOS / Linux）

1. 安装 Python 3.10+（本轮实际使用 Python 3.14），进入本目录。安装图片验证依赖：`python -m pip install -r requirements.txt`。
2. 运行：

   ```bash
   python -m app.server
   ```

3. 浏览器打开 http://127.0.0.1:8765
4. 选择 AI 服务模式和功能；勾选本地摄像授权→开启摄像头→采集画面，或选择本地 JPEG / PNG（≤2MiB、≤1600万像素）。核对预览并勾选图片提交同意后点击「识别并投射到 HUD」。AR 翻译同样必须有图；对话可以仅提交文字。

默认 **DEMO 模式**：所有回答显式标注模拟，不具备真实 OCR、图像理解或翻译能力。摄像头采集、HUD 更新、任务确认和笔记存取接口是可运行代码；HUD 在浏览器模拟，不是眼镜真显示。

## 启用真实视觉 AI（可选，需自行配置接口密钥与账单）

请先确定当地网络和账户可访问 API。密钥仅放在启动服务的终端环境变量，绝不能写到代码、浏览器或 ESP32 固件，也不要贴到聊天中。`.env.example` 是配置说明模板，服务不会自动读取 `.env`。

Windows PowerShell:

```powershell
$env:AI_PROVIDER="openai"
$env:OPENAI_API_KEY="你的API密钥"
$env:OPENAI_MODEL="gpt-4.1-mini"
python -m app.server
```

也可在同一终端运行 `.\start-live.ps1`。缺少密钥时仍会打开本地服务供查看配置错误，但真实请求返回 `503 AI_NOT_CONFIGURED`。补齐环境变量后必须重启后端。`start-demo.bat` 强制使用模拟模式；服务不会因 Live 失败自动切换 Demo。

macOS/Linux:

```bash
export AI_PROVIDER=openai
export OPENAI_API_KEY='你的API密钥'
export OPENAI_MODEL=gpt-4.1-mini
python -m app.server
```

如果模型名在你的 API 账户不可用，请按账户能力调整 `OPENAI_MODEL`，本轮沿用原项目默认值。图像在你主动点击识别时经服务端解码校验、按 EXIF 方向调整并移除元数据/尾随内容后转发；服务不落盘图片。Responses 使用 base64 图片输入与 `store:false`，详见 [OpenAI 图像文档](https://developers.openai.com/api/docs/guides/images-vision)；第三方数据处理和账户级保留规则不受本地删除功能控制。

默认每次上游连接/读取无活动超时 12 秒；仅明确的 HTTP 429/500/502/503/504 最多尝试两次，超时不自动重发以避免重复费用。浏览器还提供请求等待上限；这不是已达成的实时性能承诺。详见 [HTTP 契约](protocols/HTTP_API.md)。本地服务仅允许 loopback 同源，手机/LAN 部署需另行加入 HTTPS 和身份认证。

真实 API 验收（先自行选择一张允许传云的非敏感照片）：

```powershell
python tools/verify_live.py --image C:/test/label.png --consent-upload --kind translate
```

该命令严格检查真实模式/回答/HUD契约，输出请求 ID 和 HTTP 耗时，不保存图片或答案；不能替代人工 OCR 评分、摄像头或光学显示验收。默认运行测试不会调用云端或使用密钥。

## 运行自检

```bash
python -m unittest discover -s tests -v
```

安装 Node.js 后上述命令也会运行浏览器交互契约；可单独执行 `node --test tests/web_client.test.cjs`。无 Node 时该包装测试会明确 skip，不得记成浏览器验证通过。

本轮结果及可复现证据见 [开发日志](docs/DEVELOPMENT_LOG.md)，冻结 22 项的实现/缺口见 [需求追踪矩阵](docs/TRACEABILITY.md)，接管前状态见 [初审报告](docs/AUDIT_BASELINE.md)，硬件拆分见 [硬件架构](docs/HARDWARE_ARCHITECTURE.md)。本目录原始交付不是 Git 仓库，因此没有虚构 commit ID；初始源文件备份在上级 `.ai-glasses-backups/20261110-baseline`。

## 交付范围

- `web/index.html` — 可操作 HUD / 摄像头 / AR 字幕模拟器，包含语音浏览器兼容性退化处理
- `app/server.py` — localhost API、状态与隐私删除
- `app/provider.py` — 明确演示与真实模型服务隔离
- `app/core.py` — 笔记、任务确认流程、HUD 格式化
- `halo/main.lua` — Halo 端侧显示及按键消息最小代码（未进行实机验证）
- `docs/` — 冻结功能 F01-F22、开发架构、开源复用清单、验收标准、开发迭代
- `hardware/` — 嘉立创 PCB 前必须完成的工程门槛
- `protocols/` — 眼镜 / 手机 / HUD 消息协议草案
- `AGENTS.md` — 可直接给 Codex 的开发约束和执行顺序

## 重要边界

这不是已完成的手机原生 App、ESP32 固件、真实 AR 光学显示或可下单 Gerber。现有开源 ESP32-S3 主板参考大多无 AR 显示，不能在没有显示桥接、光学元件和工艺验证时直接照搬。参见 `docs/OPEN_SOURCE.md` 与 `hardware/PCB_CHECKLIST.md`。

本项目源代码（本次新增文件）可由使用者修改；第三方项目代码并未打包到此 ZIP，使用时要独立检查许可证和硬件风险。
