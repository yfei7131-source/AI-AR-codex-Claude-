> 历史归档，非当前最新源码；保留原始阶段内容以便追溯。

# V1.0 完整需求追踪矩阵

更新日期：2026-11-10。来源：`FEATURES_F01_F22.md`（冻结 ID/级别）、上级目录 PRD V2.0（交互与量化验收）、`AGENTS.md`（工程红线）。不调整 16 P0、5 P1、1 R，不将 AR 显示降为后续功能。

状态按完整产品功能统计：**已实现**=全部验收有对应真实证据；**部分实现**=存在可运行软件或适配代码但缺关键链路/实测；**未实现**=只有文档/建议或无对应代码。Mock、浏览器 HUD、配置模板均不等于真实云推理、原生 App、光学 AR 或硬件通过。初审与本轮交付后的整机分类仍为 **0 已实现 / 11 部分实现 / 11 未实现**；软件增量见后文和 `DEVELOPMENT_LOG.md`。

## F01–F22 追踪

| ID / 级别 | 需求及验收条件 | 场景 / 工作包 | 初审 → 当前 | 现有实现与测试证据 | 尚缺的验收与下一步 |
|---|---|---|---|---|---|
| F01 / P0 | 近视/远视/散光处方镜片；左右独立、HUD 清楚且不遮挡 | ME-01 / Gate D | 未实现 → 未实现 | `hardware/PCB_CHECKLIST.md`、PRD 处方约束；无样镜 | 眼距/眼盒/顶点距/镜片插片结构、专业验配、左右眼处方与 HUD 可读性试戴记录 |
| F02 / P0 | 鼻梁/太阳穴/耳后舒适与重心；4h 不适≤2/10 为内部目标 | ME-01 / Gate D | 未实现 → 未实现 | 机械要求仅文档；无重量/温升/压力数据 | 可调鼻托镜腿、不同头型与普通镜架对照、验配整镜重量/重心及接触温升实测 |
| F03 / P0 | 蓝牙开放式音频、接听/通话与短播报 | FW-02 / Gate C | 未实现 → 未实现 | 浏览器 TTS 只验证手机/PC侧播放，非眼镜通话 | 独立音频无线方案、手机 HFP/通话路由、回声/降噪/扬声器保护；S3 BLE 不等于经典蓝牙音频 |
| F04 / P0 | 按键/触控启动、取消与重复拍摄 | S1 / AR-01、FW-01 | 部分 → 部分 | `web/index.html` 手机按钮；`halo/main.lua` 单击发送 `CAPTURE`，Lua 尚未运行 | 官方 emulator、手机 BLE 接收、物理按键消抖/取消/超时/重复触发与相机联动 |
| F05 / P0 | ASR→上下文对话→TTS，无擅自执行 | SW-01、SW-02、FW-02 | 部分 → 部分 | `app/provider.py` chat、浏览器语音调用；`test_vision.VisionHttpTest.test_chat_without_image`；T06语音同意/退化与不自动提交测试 | 连续对话上下文、真实 ASR/TTS 端到端、噪声/拒绝权限/中断、语音隐私；浏览器支持性需人工实测 |
| F06 / P0 | 主动语音随手记，转写核对确认后保存，手机可查看删除 | SW-01、SW-02 | 部分 → 部分 | `app/core.py:Memory.note/wipe`；`test_note_lifecycle`；T05删除并发保护、T06保存笔记前确认 | 原生录音/ASR、用户编辑确认实测、持久化/导出、设备端输入及删除范围核验 |
| F07 / P0 | 从笔记/画面提摘要、日期和任务，原文可追溯 | S3 / SW-02 | 未实现 → 未实现 | 手写任务草稿不是 AI 内容整理，无结构化提取实现 | 提取 schema、来源片段、日期/时区/歧义确认、与标注文本对照测试 |
| F08 / P0 | 待确认→明确确认→真实白名单动作；幂等、失败可追溯 | S3 / SW-01、SW-02 | 部分 → 部分 | `Memory.draft_task/confirm_task`；`test_task_cannot_execute_without_confirmation`、`test_task_consent`；只 `confirmed_local_only` | 真实日历/任务适配器、授权与幂等、撤销、持久审计、失败/重试测试；不可声称已写入外部系统 |
| F09 / P0 | 原生手机 App：发现/配对、相机/音频权限、图像与状态同步 | S1–S3 / SW-02 | 部分 → 部分 | 浏览器替代手机中枢；本地 HTTP/health/state 可运行 | Flutter 工程及 Android/iOS 构建、真机权限/BLE 断连恢复、设备相机图像链路；浏览器不是原生 App |
| F10 / P0 | 显式采集/传云同意、硬件指示、停止、删除/导出与范围 | 全场景 / SW-03、FW-01 | 部分 → 部分 | `app/images.py`去元数据、`test_delete`、T01图像清理、T04同意/同源、T05删除并发、T06关闭相机和语音同意 | 物理灯与采集供电/活动联动、原生权限撤回、持久数据导出/删除、供应商保留规则、多人/账号隔离 |
| F11 / P0 | 电量/连接/充电状态、固件升级、错误日志 | FW-01、FW-02 / Gate C | 未实现 → 未实现 | `/api/health` 是服务器状态，不能作为设备遥测 | 电池计量、BLE 设备状态、带回滚/验证的 OTA 或明确有线升级、真实错误日志与断电测试 |
| F12 / P1 | 用户同意后断网暂存、恢复同步与冲突处理 | SW-02 | 未实现 → 未实现 | 进程内笔记不是持久离线队列 | 加密暂存、寿命/容量/删除范围、幂等同步与冲突/重启/断网测试 |
| F13 / P1 | 指定语言语音转写→翻译→音频反馈 | M2 / SW-02、FW-02 | 未实现 → 未实现 | 图片翻译和最终语音输入不能代替语音翻译流水线 | 语音分段、源/目标语言、真实翻译/播报、噪声/多人/超时验收 |
| F14 / P1 | 字号、语言、音量、亮度、提示及通知偏好 | SW-02、AR-02 | 未实现 → 未实现 | 运行模式切换不等于用户偏好设置 | 设置模型/持久化、手机到眼镜同步、范围/默认值/重启测试及显示亮度实测 |
| F15 / P0 | AR 光学 HUD，最多3行；室内/强光与眼盒可读性 | 全场景 / AR-01、AR-02 | 部分 → 部分 | `app/core.py:to_hud`、浏览器预览、Lua ASCII；`test_hud`和`test_vision.ImageTest.test_hud_three_lines_and_truncation`；T08浏览器截图 | 真实光学显示、中文栅格化、HUD位置/亮度/安全视野、佩戴阅读率≥90%内部目标实测 |
| F16 / P1 | 主动开启同语实时字幕，可停止、非全天监听 | M2 / SW-02、AR-02 | 未实现 → 未实现 | 单次 ASR 最终文本填输入框，未实现流式字幕 | interim/final 分段、延迟/纠错、取消、噪声/多人字幕与 HUD 帧更新测试 |
| F17 / P0 | 图像 OCR→可核对原文/译文→简短 HUD，标不确定 | S2 / SW-01、SW-03、AR-02 | 部分 → 部分 | `provider.py`真实图像/OCR提示词与`detail:high`；T02供应商payload、T04 HTTP、T06浏览器translate传图、T07实测工具契约 | 配 Key 真实 OCR 翻译照片验收、标注数据集、原文核对、中文光学 HUD；不能以固定 Demo 文案计准确率 |
| F18 / P1 | 步行简短转向导航，无 SLAM/驾车承诺 | SW-02、AR-02 | 未实现 → 未实现 | 无路线/定位/导航代码 | 手机定位授权、路线提供者/偏航、地图许可、步行场景与失败提示测试 |
| F19 / P0 | HUD 待确认任务卡、按键反馈、真实成功/失败 | S3 / SW-01、AR-02 | 部分 → 部分 | `Memory.last_hud`、浏览器确认任务卡；`test_task_consent`，T05旧AI不能覆盖新任务卡 | 真实光学任务卡与物理确认、外部执行结果、取消/失败/重复点击处理 |
| F20 / P0 | 主动摄像→上传→真实视觉理解/问答→HUD与语音 | S1 / SW-01、SW-03、FW-01 | 部分 → 部分 | `web/`→`/api/ask`→`OpenAIProvider`→`to_hud`；T01–T07图片/供应商/HTTP/浏览器/实测工具契约；T08 Demo截图 | 真实 API 成功证据/识别评分与P95时延、ESP32/平台相机、光学 HUD、眼镜播报；Mock只验证传输契约 |
| F21 / R | 空间锚定/6DoF/SLAM仅预研，不计V1交付 | 独立研究 | 未实现 → 未实现 | 架构已明确排除首代交付；无研究实现 | 单独定义可行性、数据集/跟踪/功耗评估，不能据浏览器叠加宣称空间锚定 |
| F22 / P0 | 按键/触控/手机/语音控制HUD继续、关闭、确认 | 全场景 / SW-01、AR-01、AR-02 | 部分 → 部分 | 手机网页交互与 Lua CAPTURE 示例；本地任务确认测试 | 物理输入与 HUD 生命周期、退出/取消、语音确认约束、断连/重复事件/一致状态验证 |

## 场景及横向需求追踪

| 验收 ID | 覆盖需求 | 测试与门槛 | 当前证据 / 缺口 |
|---|---|---|---|
| S1 / 即拍即问 | F04/F09/F10/F15/F20/F22 | 主动取景→同意→真实图像→真实AI→短答HUD；取消、无图、无Key、断网、坏图均有明确失败 | 本轮在现有软件主路径上补契约；真实模型、相机和光学设备证据分开归档 |
| S2 / AR翻译 | F10/F15/F17/F22 | 50张清晰标签/铭牌逐字段评分；OCR关键字段≥95%为目标；不清晰输入标不确定 | Mock响应不能计作OCR/翻译样本；待Key与真实照片数据集 |
| S3 / 看见即行动 | F07/F08/F19/F22 | 当前画面来源可追溯→提取→内容核对→用户确认→真实写入→撤销/失败 | 现仅手写草稿→本地确认；外部任务执行成功率≥99%目标尚未测 |
| Q01 / 真实与模拟隔离 | F05/F17/F20 | 响应、HUD与播报来源一致；live缺配置/出错不得返回Demo答案 | T03/T04/T06/T07明确mode/simulated与失败不降级；T08实际浏览器缺Key错误 |
| Q02 / 图像边界 | F09/F10/F20 | JPEG/PNG、0/1/2MiB、坏Base64/MIME/截断、显式同意、请求限长 | T01严格解码/元数据清理与0/1/2MiB边界，T04同意/无图，T06本地文件边界；不是整机隐私认证 |
| Q03 / 时延可靠性 | F04/F09/F15/F20/F22 | 固定网络/手机/模型≥50轮，拍摄到HUD P95≤6s内部目标；超时/退出覆盖100% | T03有限HTTP重试、超时不重试；T06前端超时/旧结果保护。测试耗时不是真实AI端到端延迟 |
| Q04 / 视觉质量 | F17/F20 | 100张预选图像，问题与人工参考答案固定；可用回答≥90%内部目标 | 未做真实评分；需区分清晰度/光照/距离并记录模型版本 |
| Q05 / 隐私删除 | F06/F08/F10/F12 | 停止媒体、清理本地状态、说明浏览器/服务/供应商边界；删除中在途响应不得重新显示 | T05后端在途推理/慢上传删除失效，T06浏览器图片/相机/语音清理和迟到响应拒绝；云端删除不在本地按钮范围 |
| Q06 / 佩戴及温升 | F01/F02/F03/F10/F15 | 裸镜目标≤50g、警戒55g；验配整镜另称重；25°C指定工况皮肤接触面≤41°C内部目标 | 全部待实测；这些为PRD内部目标，最终适用标准和安全边界需专业审查 |
| Q07 / 第三方与PCB | F01/F02/F03/F09/F11/F15 | 固定版本/许可、可买BOM、Pin Map、电源/结构审查、ERC/DRC后才导出制造文件 | 无第三方工程复制；现仍开发板/独立显示评估阶段，见 `HARDWARE_ARCHITECTURE.md` |

## 基线与本轮证据索引

- 初审测试精确名称、9/9原始结果和各目录审查见 `AUDIT_BASELINE.md`。
- 本轮改动、测试命令与真实输出、缺Key/工具/硬件的限制见 `DEVELOPMENT_LOG.md`。
- 真实供应商测试应单独记录日期、模型、`request_id`、输入类型与非敏感摘要，不提交 Key、个人图片或音频；未执行时明确写“未运行”。
- 软件完成子能力可以在日志标“测试通过”，本矩阵整机功能仅在剩余验收全部有证据后升级“已实现”。

本轮实际结果：`python -m unittest discover -s tests -v` **48/48通过**，其中 `test_web_client` 包装执行下列 **21/21 Node测试**；另行执行 `node --test tests/web_client.test.cjs` 亦通过。48与21存在包装关系，不计成69个独立Python测试。输出分别保存在 [`evidence/unittest.txt`](evidence/unittest.txt)、[`evidence/web-tests.txt`](evidence/web-tests.txt)。以下精确名称可直接在对应文件定位。

| 索引 | 代码/测试文件与精确测试名 | 覆盖范围及验证边界 |
|---|---|---|
| T01 / 图像 | `tests/test_vision.py:ImageTest`：`test_valid_jpeg_png`、`test_metadata_and_trailing_bytes_removed`、`test_reject_empty_fake_base64_url_and_mime`、`test_reject_truncated_jpeg_and_png`、`test_two_mib_limit`、`test_pixel_limit`、`test_hud_three_lines_and_truncation` | Pillow完整解码、JPEG/PNG MIME一致性；0/1/2MiB及超限、16MP上限；移除PNG元数据/尾随内容；HUD3行及省略号。图像由测试生成，不含个人媒体；不证明OCR准确率 |
| T02 / 供应商payload | `tests/test_vision.py:ProviderTest.test_live_payload_image_store_false_and_ocr_detail`、`test_live_requires_image` | 截获Responses请求验证图片原样进入供应商适配层、`store:false`、OCR `detail:high`；供应商网络为Mock，不代表服务端鉴权/模型识别通过 |
| T03 / 供应商失败 | `tests/test_vision.py:ProviderTest`：`test_unknown_provider_never_falls_back`、`test_retry_transient_http_only`、`test_auth_failure_not_retried_or_leaked`、`test_timeout_no_retry`、`test_bad_empty_incomplete_and_refusal`、`test_invalid_json_and_network`、`test_invalid_timeout_config` | 未知配置不降级；暂态HTTP有限重试，鉴权/超时不自动重试；拒答、未完成、空响应、坏JSON/网络失败可见且不泄露上游敏感内容 |
| T04 / HTTP契约 | `tests/test_vision.py:VisionHttpTest`：`test_demo_marked_in_response_and_hud`、`test_live_in_demo_server_cannot_succeed`、`test_live_adapter_to_http_hud_contract`、`test_consent_missing_false_or_truthy_rejected`、`test_image_required_and_malformed`、`test_mode_kind_and_question_types`、`test_chat_without_image`、`test_origin_and_content_type`、`test_errors_update_hud` | 启动真实localhost HTTP服务器；live适配层响应仍为离线桩。验证传图、严格boolean同意、来源、503缺配置、同源及错误HUD；`simulated:false`仅为live路由契约，不是本次真实推理证据 |
| T05 / 后端并发 | `tests/test_vision.py:VisionHttpTest.test_privacy_delete_discards_inflight_result`、`test_privacy_delete_invalidates_slow_upload_before_mutation`、`test_task_hud_supersedes_old_inference` | 删除后在途AI/慢上传不能回填HUD或笔记；新任务卡使旧AI请求409失效。线程与socket模拟并发，不涉及真实摄像硬件 |
| T06 / 浏览器交互 | `tests/web_client.test.cjs`，由 `tests/test_web_client.py:WebClientTest.test_browser_interaction_contracts` 包装；含 `camera capture remains local until explicit recognition; vision sends actual frame`、`live OCR sends chosen image with translate kind and shows live HUD source`、`live never accepts a demo response or silently retries demo`、`cloud failure replaces old result on HUD and prevents stale speech`、`client timeout produces error HUD with no unbounded spinner` 等21项 | Node DOM/相机/云端桩执行实际网页脚本：主动采集/上传同意、来源校验、超时、语音退化与确认保存、撤回/后台/离页停止轨道、删除和任务操作拒绝旧响应。相机帧与语音为测试替身，不代表物理摄像头/麦克风验收 |
| T07 / 真实验收工具自身 | `tests/test_verify_live.py:LiveVerifierTest`：`test_live_contract_sends_image_and_explicit_consent`、`test_consent_required_before_read_or_network`、`test_demo_or_unready_health_never_uploads`、`test_rejects_demo_or_malformed_success`、`test_rejects_nonlocal_or_ambiguous_urls`、`test_rejects_redirect`、`test_timeout_and_http_error_are_safe_failures`、`test_nonimage_and_oversized_are_rejected`、`test_cli_output_contains_metadata_only`、`test_invalid_json_is_safe_failure` | 验证 `tools/verify_live.py` 不向Demo上传、不接受伪live成功、只连本机、不跟随重定向、摘要不打印图像/回答。10项全部使用FakeOpener，真实API成功验收尚未运行 |
| T08 / 实际浏览器证据 | [`evidence/live-missing-key.jpg`](evidence/live-missing-key.jpg)、[`evidence/demo-image-hud.jpg`](evidence/demo-image-hud.jpg)、[`evidence/synthetic-label.png`](evidence/synthetic-label.png) | 已目视核对：前者在live的chat操作显示缺`OPENAI_API_KEY`错误HUD；后者选择合成STOP标签走Demo翻译，HUD和结果明确“模拟演示，不是真实识别”。不证明相机实际采集、真实OCR/翻译或光学AR；HTTP503另由T04断言 |

本轮独立复核：冻结22个ID无遗漏、无重复；P0=16、P1=5、R=1。部分实现为F04/F05/F06/F08/F09/F10/F15/F17/F19/F20/F22，共11项；其余11项未实现（含R项F21）。语音最终文本填入输入框不计F16流式字幕；浏览器TTS不计F03蓝牙通话；手写任务草稿不计F07 AI整理；本地确认不计F08外部执行完成。
