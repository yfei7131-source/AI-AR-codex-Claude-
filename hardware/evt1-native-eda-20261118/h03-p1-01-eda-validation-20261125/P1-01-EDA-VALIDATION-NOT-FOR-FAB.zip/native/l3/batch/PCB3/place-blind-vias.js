
const request = __CLI__.args;
const current = await eda.dmt_SelectControl.getCurrentDocumentInfo();
if (!current || current.parentProjectUuid !== request.project || current.uuid !== request.doc) {
    throw new Error('Unexpected active project/PCB in official SDK session');
}
const completed = [];
for (const {net, via} of request.routes) {
    if (!via) continue;
    const pending = await eda.pcb_PrimitiveVia.create(
        net, via.x, via.y, via.drill, via.diameter, 1, via.rule, null, false
    );
    if (!pending) throw new Error('Native SDK did not create a via');
    const id = pending.getState_PrimitiveId();
    const saved = await eda.pcb_PrimitiveVia.get(id);
    if (!saved || saved.getState_Net() !== net ||
        saved.getState_ViaType() !== 1 ||
        saved.getState_DesignRuleBlindViaName() !== via.rule) {
        throw new Error('Via readback mismatch ' + id);
    }
    completed.push(id);
}
return {project: request.project, doc: request.doc, completed};
